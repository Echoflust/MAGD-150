let bugX,bugY;

let messages = [
  "🐞","🦋","🐛","🐝","🕷️","🐜","🦗","🦟"
];

let chosenBug = ""; 

function setup() {
  createCanvas(400, 400);
  textSize(40);
}

  //location and bug randomization
function draw() {
  background(173, 216, 230);
    noStroke();
  fill(144, 238, 144);
ellipse(200,360,500,150)

    fill(255);
  rect(50,25,300,50); //top box
  rect(50,325,300,50);
    fill(0);
    textSize(40)
  text('Draw a Bug!!',85,64);
    textSize(20);
  text('Click mouse: Draw a Bug',85,345);
  text('Enter: Redraw a Bug',107,365);
      textSize(40);

  //random location of bug
  let bugX = random(width);
  let bugY = random(height);
  
chosenBug = random(messages); 

text(chosenBug,bugX,bugY);}

  //stop the randomization loop to draw a bug
function mousePressed() {
  noLoop();
}

  //reroll the randomization when enter is pressed
function keyPressed() { 
  if (keyCode === 13) { 
    loop();
  }
}